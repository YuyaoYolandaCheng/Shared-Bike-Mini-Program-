var myUtil = require("../myUtil")
Page({
  data: {
    log: 0,
    lat: 0,
    controls: [],
    markers: []
  },

  //use when load for the first time
  onLoad: function(){
    var that = this;
    wx.getLocation({
      success: function(res){
        var log = res.longitude
        var lat = res.latitude
        that.setData({
          log : log,
          lat : lat
        })
        findBikes(log, lat, that)
      },
    })

    wx.getSystemInfo({
success: function(res) {
    var windowWidth = res.windowWidth;
    var windowHeight = res.windowHeight;

    that.setData({
      controls: [
        {
          id: 1,
          iconPath: '/images/qrcode.jpeg',
          position:{
            width: 150,
            height: 60,
            left: windowWidth/2 - 75,
            top: windowHeight - 100
          }, 
          clickable: true
        },
        {
          id: 2,
          iconPath: '/images/locate.jpeg',
          position: {
            width: 60,
            height: 60,
            left: 10,
            top: windowHeight - 300
          },
          clickable: true
        },
        {
          id: 3,
          iconPath: '/images/pin.JPG',
          position:{
            width: 20,
            height: 35,
            left: windowWidth/2-10,
            top: windowHeight/2-30
          },
          clickable: true
        },
        { 
          id: 4,
          iconPath: '/images/pay.jpeg',
          position: {
            width: 60,
            height: 60,
            left: windowWidth - 65,
            top: windowHeight - 100
          },
          clickable: true
        },
        {
          id: 6,
          iconPath: "/images/repair.jpeg",
          position: {
            width: 60,
            height: 60,
            left: windowWidth - 65,
            top: windowHeight - 200
          },
          clickable: true
        },
        {
          id: 5,
          iconPath: "/images/add.jpeg",
          position: {
            width:50,
            height: 50,
          },
          clickable: true
        },
      ]
      })
},
    })
  },

  //tap handler
  controltap: function(e){
    var that = this;
    var cid = e.controlId;
    switch(cid){
      //scan
      case 1: {
        var status = myUtil.get("status")
        if(!status){
          status = getApp().globalData.status;
        }
        //redirect based on user status
        if(status == 0){
          //redirect to sign-up page
          wx.navigateTo({
            url: '../register/register',
          })
        } else if(status == 1){
          wx.navigateTo({
          url: '../deposite/deposite',
        })
      }
      else if(status == 2){
        wx.navigateTo({
          url: '../identify/identify',
        })
      }
        break;
      }
      //locate
      case 2: {
        this.mapCtx.moveToLocation()
        break;
      }
      //add a bike
      case 5: {
        //get the existed bikes
        //var bikes = that.data.markers;
        this.mapCtx.getCenterLocation({
          //get the moved map's center
          success: function(res){
            var log = res.longitude;
            var lat = res.latitude;
            //send data to SpringBoot
            wx.request({
              url:"http://localhost:60/bike/add",
              data: {
                longitude: log,
                latitude: lat,
                status: 0
              },
              method: 'POST',
              success: function(res){
                findBikes(log, lat, that)
              }
            })
          }
        })
      }
      break;
    }
  },

  regionchange: function(e){
    var that = this;
    var etype = e.type;
    if(etype == 'end'){
      this.mapCtx.getCenterLocation({
        success: function(res){
          var log = res.longitude;
          var lat = res.latitude;
          findBikes(log, lat, that)
        }
      })
    }
  },

  onReady: function(){
    //set map context
    this.mapCtx = wx.createMapContext('myMap')
  }
})

function findBikes(longitude, latitude, that){
  wx.request({
    url: 'http://localhost:60/bike/findNear',
    method: 'GET',
    data: {
      longitude: longitude,
      latitude: latitude
    },
    success: function(res){
      var bikes = res.data.map((bike) => {
        return {
          longitude: bike.longitude,
          latitude: bike.latitude,
          iconPath: "/images/bike.png",
          width: 40,
          height: 40,
          id: bike.Id
        }
      })
      that.setData({
        markers: bikes
      })
    }
  })
}