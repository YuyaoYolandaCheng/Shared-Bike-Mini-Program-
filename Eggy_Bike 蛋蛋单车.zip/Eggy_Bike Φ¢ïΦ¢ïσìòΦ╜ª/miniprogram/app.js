//app.js
App({
  onLaunch: function(){
    
  },
  //all pages share
  globalData: {
    userInfo: null,
    status: 0,
    phoneNum: "",
    deposite: 0
  }
})